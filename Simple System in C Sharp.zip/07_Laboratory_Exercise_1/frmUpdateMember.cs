﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_Laboratory_Exercise_1
{
    public partial class frmUpdateMember : Form
    {
        private ClubRegistrationQuery clubRegistrationQuery;
        SqlConnection sqlConnect = new SqlConnection(@"Data Source=LAPTOP-VE7RJ07I\SQLEXPRESS;Initial Catalog=ClubDB;Integrated Security=True");
        SqlCommand sqlCommand;
        SqlDataReader sqlReader;

        private int Age, Id;
        private string FirstName, MiddleName, LastName, Gender, Program;
        public frmUpdateMember()
        {
            InitializeComponent();
            FillCombo();
            
        }

        private void frmUpdateMember_Load(object sender, EventArgs e)
        {
            clubRegistrationQuery = new ClubRegistrationQuery();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (txtFname.Text == "" || txtMname.Text == ""
                || txtLname.Text == "" || txtAge.Text == "" || cbGender.SelectedIndex == -1 || cbProgram.SelectedIndex == -1)
            {
                MessageBox.Show("Fill up the required field/s", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else 
            {
                try 
                {
                    UpdateData();
                    clubRegistrationQuery.UpdateStudent(Id, FirstName, MiddleName, LastName, Age, Gender, Program);
                    ClearInput();
                }
                catch (Exception ex) 
                {
                    MessageBox.Show("Message Update: " + ex.Message);
                 }
            }
        }

        public void FillCombo()
        {
            string filldata = "SELECT * FROM ClubMembers";
            sqlCommand = new SqlCommand(filldata, sqlConnect);
            try
            {
                sqlConnect.Open();
                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    long studentid = sqlReader.GetInt64(1);
                    cbStudentID.Items.Add(studentid);
                }
                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Message: " + ex.Message);
            }
        }

        private void cbStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string updateData = "SELECT * FROM ClubMembers WHERE StudentId ='"+cbStudentID.Text+"'; ";
                sqlCommand = new SqlCommand(updateData, sqlConnect);
                sqlConnect.Open();

                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    int id = sqlReader.GetInt32(0);
                    string fname = sqlReader.GetString(2);
                    string mname = sqlReader.GetString(3);
                    string lname = sqlReader.GetString(4);
                    int age = sqlReader.GetInt32(5);
                    string gender = sqlReader.GetString(6);
                    string program = sqlReader.GetString(7);

                    txtid.Text = id.ToString();
                    txtFname.Text = fname;
                    txtMname.Text = mname;
                    txtLname.Text = lname;
                    txtAge.Text = age.ToString();
                    cbGender.Text = gender;
                    cbProgram.Text = program;
                }
                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Message: " + ex.Message);
            }
        }
        public void ClearInput()
        {
            txtid.Clear();
            cbStudentID.SelectedIndex = -1;
            txtFname.Clear();
            txtMname.Clear();
            txtLname.Clear();
            txtAge.Clear();
            cbGender.SelectedIndex = -1;
            cbProgram.SelectedIndex = -1;
        }

        public void UpdateData()
        {
            Id = Convert.ToInt32(txtid.Text);
            FirstName = txtFname.Text;
            MiddleName = txtMname.Text;
            LastName = txtLname.Text;
            Age = Convert.ToInt32(txtAge.Text);
            Gender = cbGender.Text;
            Program = cbProgram.Text;

        }
    }
}
